import { useState, useCallback, useEffect, useMemo } from 'react';
import { basePriceBySize, extraPriceBySize } from '../../../mocks/services';

const sizeImages: Record<string, string> = {
  'berlina-suv': 'https://readdy.ai/api/search-image?query=realistic%20photograph%20of%20a%20black%20SUV%20parked%20inside%20an%20auto%20detailing%20garage%20being%20washed%20with%20thick%20white%20foam%20covering%20the%20hood%2C%20natural%20workshop%20lighting%20from%20overhead%20fluorescent%20tubes%2C%20concrete%20floor%20with%20water%20puddles%2C%20no%20people%20visible%2C%20candid%20documentary%20style%20photo%2C%20slight%20grain%20texture%2C%20realistic%20reflections%20on%20wet%20paint%2C%20authentic%20car%20wash%20bay%20atmosphere%20not%20studio%20rendered&width=800&height=600&seq=basic-suv-real-v2&orientation=landscape',
  '7-plazas': 'https://readdy.ai/api/search-image?query=realistic%20photograph%20of%20a%20silver%20family%20minivan%20rear%20three%20quarter%20view%20inside%20a%20car%20wash%20garage%2C%20thick%20soap%20foam%20on%20the%20back%20and%20side%20panels%2C%20natural%20overhead%20garage%20lighting%2C%20wet%20concrete%20floor%2C%20no%20people%20visible%2C%20authentic%20workshop%20environment%2C%20documentary%20photography%20style%2C%20realistic%20water%20droplets%20and%20reflections%20on%20bodywork%2C%20candid%20unposed%20shot&width=800&height=600&seq=basic-7plazas-real-v2&orientation=landscape',
  furgoneta: 'https://readdy.ai/api/search-image?query=realistic%20photograph%20of%20a%20white%20commercial%20van%20side%20view%20being%20pressure%20washed%20inside%20an%20auto%20detailing%20workshop%2C%20thick%20foam%20running%20down%20the%20metal%20side%20panel%2C%20natural%20garage%20lighting%20with%20some%20shadows%2C%20concrete%20floor%20with%20water%20and%20soap%2C%20no%20people%20visible%2C%20authentic%20candid%20photo%20style%2C%20realistic%20texture%20on%20vehicle%20body%2C%20workshop%20tools%20slightly%20visible%20in%20background&width=800&height=600&seq=basic-furgoneta-real-v2&orientation=landscape',
};

const sizeLabelMap: Record<string, string> = {
  utilitario: 'Utilitario',
  'berlina-suv': 'Berlina / SUV',
  '7-plazas': '7 Plazas',
  furgoneta: 'Furgoneta',
};

const extraShortNameMap: Record<string, string> = {
  'Limpieza de tapicería (inyección y extracción profesional)': 'Tapicería',
  'Vapor y desinfección interior': 'Vapor',
  'Eliminar pelos de mascota': 'Mascota',
  'Limpieza de alfombrillas con cepillo rotativo': 'Alfombrillas',
  'Limpieza de motor básica': 'Motor',
};

interface Extra {
  name: string;
  price: number;
}

interface BasicServiceProps {
  service: {
    id: string;
    name: string;
    slogan?: string;
    price: number;
    duration?: string;
    image: string;
    included: string[];
    extras: Extra[];
  };
  vehicleSize?: string | null;
}

export default function BasicService({ service, vehicleSize }: BasicServiceProps) {
  const [selectedExtras, setSelectedExtras] = useState<Record<number, boolean>>({});
  const [isExpanded, setIsExpanded] = useState(false);

  const size = vehicleSize || 'utilitario';
  const basePrice = basePriceBySize[size] ?? service.price;
  const currentImage = sizeImages[size] ?? service.image;

  const adjustedExtras = service.extras.map((extra) => ({
    ...extra,
    price: extraPriceBySize[extra.name]?.[size] ?? extra.price,
  }));

  const totalPrice =
    basePrice +
    adjustedExtras.reduce(
      (sum, extra, i) => sum + (selectedExtras[i] ? extra.price : 0),
      0,
    );

  const selectedExtrasList = adjustedExtras.filter((_, i) => selectedExtras[i]);

  const whatsappUrl = useMemo(() => {
    const vehicleLabel = sizeLabelMap[size] ?? size;
    const lines = [
      `*${vehicleLabel}*`,
      `*${service.name}*`,
    ];
    selectedExtrasList.forEach((extra) => {
      const shortName = extraShortNameMap[extra.name] ?? extra.name;
      lines.push(`+${shortName}`);
    });
    lines.push(`Total: ${totalPrice}€`);
    const text = lines.join('\n');
    return `https://wa.me/34676758480?text=${encodeURIComponent(text)}`;
  }, [size, service.name, selectedExtrasList, totalPrice]);

  const toggleExtra = useCallback((index: number) => {
    setSelectedExtras((prev) => ({
      ...prev,
      [index]: !prev[index],
    }));
  }, []);

  return (
    <div className="w-full max-w-7xl mx-auto">
      {/* ========== MOBILE LAYOUT ========== */}
      <div className="block md:hidden">
        {/* Card compacta */}
        <div className="rounded-2xl overflow-hidden border border-[#FFB800]/40 bg-[#111]">
          {/* Foto más pequeña */}
          <div key={size} className="relative h-[180px] overflow-hidden animate-cross-fade">
            <img
              src={currentImage}
              alt={service.name}
              className="w-full h-full object-cover object-top"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black/70 pointer-events-none" />
          </div>

          {/* Info compacta */}
          <div className="bg-[#111] px-4 pt-2.5 pb-3 flex flex-col items-start">
            {service.slogan && (
              <p className="text-[#FFB800] text-[9px] font-light tracking-[0.2em] uppercase mb-0.5">
                {service.slogan}
              </p>
            )}

            <h3 className="text-white text-sm font-light tracking-[0.1em] uppercase mb-1 leading-tight">
              {service.name}
            </h3>

            <p className="text-[#FFB800] text-xl font-bold mb-0.5 leading-none">
              <span key={basePrice} className="animate-price-pop">{basePrice}€</span>
            </p>

            {service.duration && (
              <p className="text-white/40 text-[9px] font-light mb-2">{service.duration}</p>
            )}

            {/* MÁS INFO — pequeño y a la izquierda */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsExpanded(!isExpanded);
              }}
              className="self-start border border-[#FFB800]/60 text-[#FFB800] py-1 px-3 rounded-full font-light text-[9px] tracking-[0.12em] uppercase active:bg-[#FFB800]/20 transition-colors duration-150 whitespace-nowrap cursor-pointer"
            >
              {isExpanded ? 'MENOS INFO' : 'MÁS INFO'}
            </button>
          </div>

          {/* Desplegable: incluye */}
          <div
            className="overflow-hidden transition-all duration-300 ease-in-out"
            style={{ maxHeight: isExpanded ? '400px' : '0px' }}
          >
            <div className="px-4 pb-3 pt-2 border-t border-[#FFB800]/10">
              <p className="text-[#FFB800] text-[9px] font-light tracking-[0.15em] uppercase mb-2">
                Incluye:
              </p>
              <ul className="space-y-1">
                {service.included.map((item, i) => (
                  <li key={i} className="text-white/70 text-[10px] flex items-start gap-1.5">
                    <span className="flex-shrink-0 w-3.5 h-3.5 rounded-full border border-[#FFB800]/60 flex items-center justify-center">
                      <i className="ri-check-line text-[#FFB800] text-[6px]" />
                    </span>
                    <span className="leading-snug">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Extras siempre visibles en móvil, debajo de la card */}
        <div key={size} className="mt-3 px-1 animate-fade-in-fast">
          <p className="text-[#FFB800] text-[9px] font-light tracking-[0.2em] uppercase mb-2">
            Extras disponibles:
          </p>
          <div className="space-y-2">
            {adjustedExtras.map((extra, i) => {
              const isSelected = !!selectedExtras[i];
              return (
                <button
                  key={i}
                  onClick={() => toggleExtra(i)}
                  className={`animate-stagger-up stagger-${Math.min(i + 1, 5)} w-full flex items-center justify-between gap-2 py-3.5 px-3 rounded-xl border transition-all duration-100 text-left cursor-pointer touch-manipulation select-none ${isSelected ? 'border-[#FFB800] bg-[#FFB800]/10 active:scale-[0.98]' : 'border-white/15 bg-white/5 active:bg-white/10 active:scale-[0.98]'}`}
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className={`flex-shrink-0 w-5 h-5 rounded-full border flex items-center justify-center transition-colors duration-150 ${isSelected ? 'border-[#FFB800] bg-[#FFB800]' : 'border-white/40'}`}
                    >
                      {isSelected && <i className="ri-check-line text-black text-[10px]" />}
                    </span>
                    <span
                      className={`text-[11px] leading-snug ${isSelected ? 'text-white' : 'text-white/70'}`}
                    >
                      {extra.name}
                    </span>
                  </div>
                  <span
                    className={`flex-shrink-0 text-[10px] font-semibold ${isSelected ? 'text-[#FFB800]' : 'text-white/50'}`}
                  >
                    +{extra.price}€
                  </span>
                </button>
              );
            })}
          </div>

          {/* Total móvil */}
          <div className="flex items-center justify-between border-t border-[#FFB800]/20 pt-3 mt-3 mb-1">
            <span className="text-white/50 text-[9px] tracking-wider uppercase">Total estimado</span>
            <span className="text-[#FFB800] text-xl font-bold"><span key={totalPrice} className="animate-price-pop">{totalPrice}€</span></span>
          </div>

          <p className="text-white/30 text-[8px] italic text-center mb-3 px-2 leading-relaxed">
            Precio orientativo. El coste definitivo se confirma tras valoración presencial en función del estado del vehículo.
          </p>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full bg-[#FFB800] text-black py-2.5 rounded-full font-semibold text-[10px] tracking-[0.12em] uppercase active:bg-[#FF9500] transition-colors duration-150 text-center flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <i className="ri-whatsapp-line text-xs" />
            RESERVAR LAVADO BÁSICO
          </a>
        </div>
      </div>

      {/* ========== DESKTOP LAYOUT ========== */}
      <div className="hidden md:flex gap-6 items-stretch">
        {/* Card izquierda: se estira a la altura de la derecha */}
        <div className="w-[340px] flex-shrink-0 rounded-2xl overflow-hidden border border-[#FFB800]/40 bg-[#111] flex flex-col">
          {/* Foto arriba */}
          <div key={size} className="relative flex-1 min-h-0 overflow-hidden animate-cross-fade">
            <img
              src={currentImage}
              alt={service.name}
              className="w-full h-full object-cover object-top"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black/70 pointer-events-none" />
          </div>

          {/* Info abajo, compacta */}
          <div className="flex-shrink-0 bg-[#111] px-5 py-4">
            {service.slogan && (
              <p className="text-[#FFB800] text-[10px] font-light tracking-[0.2em] uppercase mb-1">
                {service.slogan}
              </p>
            )}

            <h3 className="text-white text-lg font-light tracking-[0.12em] uppercase mb-1.5 leading-tight">
              {service.name}
            </h3>

            <p className="text-[#FFB800] text-3xl font-bold mb-0.5 leading-none">
              <span key={basePrice} className="animate-price-pop">{basePrice}€</span>
            </p>

            {service.duration && (
              <p className="text-white/40 text-[10px] font-light">{service.duration}</p>
            )}
          </div>
        </div>

        {/* Extras a la derecha */}
        <div key={size} className="flex-1 min-w-0 flex flex-col animate-fade-in-fast">
          <p className="text-[#FFB800] text-xs font-light tracking-[0.2em] uppercase mb-4">
            Personaliza tu servicio:
          </p>

          <div className="space-y-3 flex-1">
            {adjustedExtras.map((extra, i) => {
              const isSelected = !!selectedExtras[i];
              return (
                <button
                  key={i}
                  onClick={() => toggleExtra(i)}
                  className={`animate-stagger-up stagger-${Math.min(i + 1, 5)} w-full flex items-center justify-between gap-3 py-4 px-4 rounded-2xl border transition-all duration-100 text-left cursor-pointer touch-manipulation select-none ${isSelected ? 'border-[#FFB800] bg-[#FFB800]/10 active:scale-[0.98]' : 'border-white/15 bg-[#1a1a1a] hover:bg-[#222] active:bg-white/10 active:scale-[0.98]'}`}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className={`flex-shrink-0 w-5 h-5 rounded-full border flex items-center justify-center transition-colors duration-150 ${isSelected ? 'border-[#FFB800] bg-[#FFB800]' : 'border-white/40'}`}
                    >
                      {isSelected && <i className="ri-check-line text-black text-xs" />}
                    </span>
                    <span
                      className={`text-sm leading-snug ${isSelected ? 'text-white' : 'text-white/70'}`}
                    >
                      {extra.name}
                    </span>
                  </div>
                  <span
                    className={`flex-shrink-0 text-sm font-semibold ${isSelected ? 'text-[#FFB800]' : 'text-white/50'}`}
                  >
                    +{extra.price}€
                  </span>
                </button>
              );
            })}
          </div>

          {/* Total */}
          <div className="flex items-center justify-between border-t border-[#FFB800]/20 pt-5 mt-5 mb-2">
            <span className="text-white/50 text-sm tracking-wider uppercase">Total estimado</span>
            <span className="text-[#FFB800] text-4xl font-bold"><span key={totalPrice} className="animate-price-pop">{totalPrice}€</span></span>
          </div>

          <p className="text-white/30 text-xs italic text-left mb-5 px-2 leading-relaxed">
            Precio orientativo. El coste definitivo se confirma tras valoración presencial en función del estado del vehículo.
          </p>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full bg-[#FFB800] text-black py-4 rounded-full font-semibold text-sm tracking-[0.15em] uppercase active:bg-[#FF9500] transition-colors duration-150 text-center flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
          >
            <i className="ri-whatsapp-line text-lg" />
            RESERVAR LAVADO BÁSICO
          </a>
        </div>
      </div>
    </div>
  );
}