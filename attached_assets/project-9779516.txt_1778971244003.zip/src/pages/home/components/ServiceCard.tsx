import { useState, useRef, useEffect, useMemo } from 'react';
import { detailedPriceBySize, durationBySize, essentialImagesBySize, absoluteImagesBySize } from '../../../mocks/services';

const sizeLabelMap: Record<string, string> = {
  utilitario: 'Utilitario',
  'berlina-suv': 'Berlina / SUV',
  '7-plazas': '7 Plazas',
  furgoneta: 'Furgoneta',
};

interface Service {
  id: string;
  name: string;
  slogan?: string;
  price: number;
  duration?: string;
  image: string;
  included: string[];
}

interface ServiceCardProps {
  service: Service;
  isActive?: boolean;
  isExpanded?: boolean;
  onToggle?: (id: string) => void;
  vehicleSize?: string | null;
}

export default function ServiceCard({
  service,
  isActive = true,
  isExpanded: isExpandedProp,
  onToggle,
  vehicleSize,
}: ServiceCardProps) {
  // Desktop: controlled by parent | Mobile: internal state
  const [isExpandedLocal, setIsExpandedLocal] = useState(false);
  const isControlled = isExpandedProp !== undefined;
  const isExpanded = isControlled ? isExpandedProp : isExpandedLocal;

  const cardRef = useRef<HTMLDivElement>(null);

  const size = vehicleSize || 'utilitario';
  const sizePrices = detailedPriceBySize[size];
  const adjustedPrice = sizePrices?.[service.id] ?? service.price;
  const adjustedDuration = durationBySize[service.id]?.[size] ?? service.duration;

  const currentImage =
    service.id === 'essential'
      ? essentialImagesBySize[size] ?? service.image
      : service.id === 'absolute'
        ? absoluteImagesBySize[size] ?? service.image
        : service.image;

  const vehicleLabel = sizeLabelMap[size] ?? size;
  const whatsappUrl = useMemo(() => {
    const lines = [
      `*${vehicleLabel}*`,
      `*${service.name}*`,
      `Total: ${adjustedPrice}€`,
    ];
    const text = lines.join('\n');
    return `https://wa.me/34676758480?text=${encodeURIComponent(text)}`;
  }, [vehicleLabel, service.name, adjustedPrice]);

  // Click outside to close (both mobile & desktop)
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (cardRef.current && !cardRef.current.contains(event.target as Node)) {
        if (isControlled && onToggle) {
          onToggle(service.id); // will set to null because prev === id ? null : id won't match if already closed
        } else {
          setIsExpandedLocal(false);
        }
      }
    };
    if (isExpanded) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isExpanded, isControlled, onToggle, service.id]);

  // Mobile: close when card leaves center
  useEffect(() => {
    if (!isControlled && !isActive) {
      setIsExpandedLocal(false);
    }
  }, [isActive, isControlled]);

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isControlled && onToggle) {
      onToggle(service.id);
    } else if (isActive) {
      setIsExpandedLocal((prev) => !prev);
    }
  };

  return (
    <div
      ref={cardRef}
      className="w-full rounded-2xl overflow-hidden border border-[#FFB800]/40"
      style={{ background: '#111' }}
    >
      {/* Foto */}
      <div className="relative overflow-hidden" style={{ height: 'clamp(140px, 28vw, 240px)' }}>
        <img
          src={currentImage}
          alt={service.name}
          className="w-full h-full object-cover object-top"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black/70 pointer-events-none"></div>
      </div>

      {/* Info */}
      <div className="bg-[#111] px-3 md:px-5 pt-3 md:pt-4 pb-3 md:pb-4">
        {service.slogan && (
          <p className="text-[#FFB800] text-[8px] md:text-xs font-light tracking-[0.15em] uppercase mb-0.5">
            {service.slogan}
          </p>
        )}

        <h3 className="text-white text-sm md:text-xl font-light tracking-[0.1em] uppercase mb-1 md:mb-1.5 leading-tight">
          {service.name}
        </h3>

        <p
          className="text-[#FFB800] text-xl md:text-4xl font-bold mb-0.5 leading-none"
        >
          {adjustedPrice}€
        </p>

        {adjustedDuration && (
          <p className="text-white/40 text-[8px] md:text-xs font-light mb-3 md:mb-4">
            {adjustedDuration}
          </p>
        )}

        {/* Botones: MÁS INFO + RESERVAR */}
        <div className="flex gap-2">
          <button
            onClick={handleToggle}
            className="flex-1 border border-[#FFB800]/60 text-[#FFB800] py-1.5 md:py-2 rounded-full font-light text-[8px] md:text-[11px] tracking-[0.1em] uppercase hover:bg-[#FFB800]/10 transition-all duration-300 whitespace-nowrap cursor-pointer"
          >
            {isExpanded ? 'MENOS INFO' : 'MÁS INFO'}
          </button>
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="flex-1 bg-[#FFB800] text-black py-1.5 md:py-2 rounded-full font-light text-[8px] md:text-[11px] tracking-[0.1em] uppercase hover:bg-[#FFA500] transition-all duration-300 text-center flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap"
          >
            <i className="ri-whatsapp-line text-xs md:text-sm"></i>
            RESERVAR
          </a>
        </div>
      </div>

      {/* Desplegable de detalles */}
      <div
        className="overflow-hidden transition-all duration-500 ease-in-out"
        style={{ maxHeight: isExpanded ? '1000px' : '0px' }}
      >
        <div className="px-3 md:px-5 pb-4 md:pb-5 pt-3 md:pt-4 border-t border-[#FFB800]/10">
          <p className="text-[#FFB800] text-[8px] md:text-xs font-light tracking-[0.15em] uppercase mb-2 md:mb-3">
            Incluye lo mismo que el essential más:
          </p>
          <ul className="space-y-1.5 md:space-y-2 mb-4 md:mb-5">
            {service.included.map((item, i) => {
              const isHeader = item.startsWith('* ');
              const displayText = isHeader ? item.slice(2) : item;
              return (
                <li
                  key={i}
                  className={`leading-relaxed flex items-start gap-1.5 ${
                    isHeader
                      ? 'text-[#FFB800] text-[9px] md:text-xs font-semibold mt-2 mb-1'
                      : 'text-white/60 text-[9px] md:text-xs'
                  }`}
                >
                  {!isHeader && (
                    <span className="flex-shrink-0 w-3.5 h-3.5 md:w-4 md:h-4 rounded-full border border-[#FFB800]/60 flex items-center justify-center mt-0">
                      <i className="ri-check-line text-[#FFB800] text-[6px] md:text-[8px]"></i>
                    </span>
                  )}
                  {isHeader && (
                    <span className="flex-shrink-0 w-3.5 h-3.5 md:w-4 md:h-4 flex items-center justify-center">
                      <i className="ri-add-line text-[#FFB800] text-[8px] md:text-[10px]"></i>
                    </span>
                  )}
                  <span>{displayText}</span>
                </li>
              );
            })}
          </ul>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="w-full bg-[#FFB800] text-black py-2 md:py-2.5 rounded-full font-semibold text-[8px] md:text-xs tracking-[0.15em] uppercase hover:bg-[#FFA500] transition-all duration-300 text-center flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <i className="ri-whatsapp-line text-xs md:text-sm"></i>
            RESERVAR {service.name.split(' ')[0].toUpperCase()}
          </a>
        </div>
      </div>
    </div>
  );
}