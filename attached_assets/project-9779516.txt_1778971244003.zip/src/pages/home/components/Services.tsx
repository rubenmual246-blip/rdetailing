import { useState, useCallback, useMemo } from 'react';
import {
  basicService,
  detailedServices,
  basePriceBySize,
  extraPriceBySize,
  detailedPriceBySize,
  durationBySize,
  sizeLabelMap,
  essentialImagesBySize,
  absoluteImagesBySize,
} from '../../../mocks/services';

interface ServicesProps {
  selectedVehicleSize: string | null;
}

export default function Services({ selectedVehicleSize }: ServicesProps) {
  const [expandedService, setExpandedService] = useState<'basic' | 'absolute' | null>(null);
  const [selectedExtras, setSelectedExtras] = useState<Record<number, boolean>>({});
  const [hasPetHair, setHasPetHair] = useState(false);

  const size = selectedVehicleSize || 'pequeno';
  const vehicleLabel = sizeLabelMap[size] ?? size;

  const basicPrice = basePriceBySize[size] ?? basicService.price;
  const absoluteService = detailedServices[0];
  const absolutePrice = detailedPriceBySize[size]?.absolute ?? absoluteService.price;
  const absoluteDuration = durationBySize['absolute']?.[size] ?? absoluteService.duration;

  const adjustedExtras = basicService.extras.map((extra) => ({
    ...extra,
    price: extraPriceBySize[extra.name]?.[size] ?? extra.price,
  }));

  const petHairPrice = extraPriceBySize['Eliminación de pelos de mascota']?.[size] ?? 15;

  const basicTotal =
    basicPrice +
    (hasPetHair ? petHairPrice : 0) +
    adjustedExtras.reduce((sum, extra, i) => {
      return sum + (selectedExtras[i] ? extra.price : 0);
    }, 0);

  const basicSelectedList = adjustedExtras.filter((extra, i) => selectedExtras[i]);

  const extraShortNameMap: Record<string, string> = {
    'Tapicería (inyección y extracción)': 'más tapicería',
    'Alfombrillas profundas': 'más alfombrillas',
    'Eliminación de pelos de mascota': 'más pelos mascota',
  };

  const basicWhatsappUrl = useMemo(() => {
    const lines = [
      `*${vehicleLabel}*`,
      `*${basicService.name}*`,
    ];
    basicSelectedList.forEach((extra) => {
      const shortName = extraShortNameMap[extra.name] ?? extra.name;
      lines.push(shortName);
    });
    if (hasPetHair) {
      lines.push('más pelos mascota');
    }
    lines.push(`Total: ${basicTotal}€`);
    const text = lines.join('\n');
    return `https://wa.me/34676758480?text=${encodeURIComponent(text)}`;
  }, [vehicleLabel, basicSelectedList, basicTotal, hasPetHair]);

  const absoluteWhatsappUrl = useMemo(() => {
    const lines = [
      `*${vehicleLabel}*`,
      `*${absoluteService.name}*`,
      `Total: ${absolutePrice}€`,
    ];
    const text = lines.join('\n');
    return `https://wa.me/34676758480?text=${encodeURIComponent(text)}`;
  }, [vehicleLabel, absoluteService.name, absolutePrice]);

  const toggleService = useCallback((service: 'basic' | 'absolute') => {
    setExpandedService((prev) => (prev === service ? null : service));
  }, []);

  const toggleExtra = useCallback((index: number) => {
    setSelectedExtras((prev) => ({
      ...(prev ?? {}),
      [index]: !(prev ?? {})[index],
    }));
  }, []);

  const basicImage = essentialImagesBySize[size] ?? basicService.image;
  const absoluteImage = absoluteImagesBySize[size] ?? absoluteService.image;
  const isBasicOpen = expandedService === 'basic';
  const isAbsoluteOpen = expandedService === 'absolute';

  const extrasPanel = (
    <div className="flex flex-col gap-3 md:gap-4 animate-[fadeIn_0.3s_ease-out]">
      {/* Título pequeño encima de los extras */}
      <p className="text-white/40 text-[10px] md:text-xs tracking-[0.2em] uppercase font-light">
        selecciona tu extra
      </p>

      {/* Toggle pelo de mascota */}
      <div className="flex items-center justify-between gap-3">
        <p className="text-white/70 text-xs md:text-sm font-light">
          ¿Tienes pelo de mascota en el coche?
          {hasPetHair && (
            <span className="block text-[#FFB800]/70 text-[10px] md:text-xs mt-0.5">Obligatorio incluir este servicio</span>
          )}
        </p>
        <button
          onClick={(e) => {
            e.stopPropagation();
            setHasPetHair((prev) => !prev);
          }}
          className={`relative w-12 h-7 md:w-14 md:h-8 rounded-full transition-colors duration-200 cursor-pointer flex-shrink-0 ${
            hasPetHair ? 'bg-[#FFB800]' : 'bg-white/20'
          }`}
        >
          <span
            className={`absolute top-0.5 left-0.5 w-6 h-6 md:w-7 md:h-7 rounded-full bg-white shadow-sm transition-transform duration-200 ${
              hasPetHair ? 'translate-x-5 md:translate-x-6' : 'translate-x-0'
            }`}
          />
        </button>
      </div>

      {/* Extras como botones horizontales alargados, uno encima del otro */}
      <div className="flex flex-col gap-2 md:gap-3">
        {adjustedExtras.map((extra, i) => {
          const isSelected = !!selectedExtras[i];

          return (
            <button
              key={i}
              onClick={(e) => {
                e.stopPropagation();
                toggleExtra(i);
              }}
              className={`w-full flex items-center justify-between gap-3 px-4 py-3 md:px-6 md:py-4 rounded-xl border transition-all duration-200 text-left touch-manipulation select-none animate-stagger-in ${
                i === 0 ? 'stagger-delay-0' : i === 1 ? 'stagger-delay-1' : 'stagger-delay-2'
              } ${
                isSelected
                  ? 'border-[#FFB800]/50 bg-[#FFB800]/15'
                  : 'border-white/10 bg-[#111] hover:border-white/25 hover:bg-white/[0.04]'
              } cursor-pointer active:scale-[0.98]`}
            >
              <span className={`text-xs md:text-sm ${isSelected ? 'text-white' : 'text-white/60'}`}>
                {extra.name}
              </span>
              <span className={`text-xs md:text-sm font-medium flex-shrink-0 ${isSelected ? 'text-[#FFB800]' : 'text-white/40'}`}>
                +{extra.price}€
              </span>
            </button>
          );
        })}
      </div>

      {/* Total */}
      <div className="flex items-center justify-between border-t border-[#FFB800]/20 pt-3 md:pt-4">
        <span className="text-white/50 text-xs md:text-sm tracking-wider uppercase">Total estimado</span>
        <span className="text-[#FFB800] text-2xl md:text-4xl font-bold">{basicTotal}€</span>
      </div>

      <p className="text-white/30 text-[10px] md:text-xs italic text-center px-2 leading-relaxed">
        Precio orientativo. El coste definitivo se confirma tras valoración presencial en función del estado del vehículo.
      </p>

      <a
        href={basicWhatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="w-full bg-[#FFB800] text-black py-3 md:py-4 rounded-full font-semibold text-xs md:text-sm tracking-[0.15em] uppercase active:bg-[#FF9500] transition-colors duration-150 text-center flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
      >
        <i className="ri-whatsapp-line text-sm md:text-lg" />
        RESERVAR LAVADO BÁSICO
      </a>
    </div>
  );

  return (
    <section id="services" className="bg-black pt-14 md:pt-20 pb-16 md:pb-24">
      <div className="max-w-5xl mx-auto px-4 md:px-6">
        {/* Título */}
        <div className="text-center mb-6 md:mb-10">
          <h3 className="text-xl md:text-3xl font-bold tracking-widest text-white">
            SERVICIOS
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-8" id="services-grid">
          {/* === LAVADO BÁSICO === */}
          <div className="order-1">
            <div
              className={`rounded-2xl overflow-hidden border bg-[#111] transition-all duration-300 relative animate-breathe ${
                isBasicOpen ? 'border-[#FFB800] ring-1 ring-[#FFB800]/30' : 'border-[#FFB800]/40'
              }`}
            >
              {/* Circuito indicador esquina superior izquierda */}
              <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5">
                <span
                  className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                    isBasicOpen
                      ? 'bg-[#FFB800] shadow-[0_0_10px_rgba(255,184,0,0.7)]'
                      : 'bg-white/15'
                  }`}
                />
                <span className={`text-[9px] md:text-[10px] tracking-wider uppercase font-light transition-colors duration-300 ${isBasicOpen ? 'text-[#FFB800]' : 'text-white/20'}`}>
                  {isBasicOpen ? 'Seleccionado' : ''}
                </span>
              </div>

              {/* Botón más info esquina superior derecha */}
              <div className="absolute top-3 right-3 z-10">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleService('basic');
                  }}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-full border text-[9px] md:text-[10px] font-medium tracking-wider uppercase transition-all duration-300 cursor-pointer ${
                    isBasicOpen
                      ? 'border-[#FFB800] bg-[#FFB800]/20 text-[#FFB800]'
                      : 'border-white/30 bg-black/40 text-white/70 backdrop-blur-sm'
                  }`}
                >
                  <i className={`ri-${isBasicOpen ? 'arrow-up-s' : 'cursor'}-line text-xs`} />
                  {isBasicOpen ? 'cerrar' : 'más info'}
                </button>
              </div>

              <button
                onClick={() => toggleService('basic')}
                className="group relative w-full text-left cursor-pointer select-none touch-manipulation"
              >
                <div className="relative h-[200px] md:h-[260px] overflow-hidden">
                  <img
                    src={basicImage}
                    alt={basicService.name}
                    className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/50 pointer-events-none" />
                </div>
                <div className="px-5 py-4 md:px-6 md:py-5">
                  {basicService.slogan && (
                    <p className="text-[#FFB800] text-[10px] md:text-xs font-light tracking-[0.2em] uppercase mb-1">
                      {basicService.slogan}
                    </p>
                  )}
                  <h3 className="text-white text-base md:text-xl font-light tracking-[0.12em] uppercase mb-2 leading-tight">
                    {basicService.name}
                  </h3>
                  <p className="text-[#FFB800] text-2xl md:text-4xl font-bold leading-none mb-1">
                    {basicPrice}€
                  </p>
                  {basicService.duration && (
                    <p className="text-white/40 text-[10px] md:text-xs font-light">{basicService.duration}</p>
                  )}

                  {!isBasicOpen && (
                    <div className="flex items-center gap-2 mt-3 md:mt-4">
                      {/* Botón reservar */}
                      <a
                        href={basicWhatsappUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="flex-1 bg-[#FFB800] text-black rounded-full py-1.5 md:py-2 px-3 text-[10px] md:text-xs font-semibold tracking-wide uppercase hover:bg-[#FFA500] transition-colors duration-200 flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-whatsapp-line" />
                        Reservar
                      </a>

                      {/* Indicador más info */}
                      <div
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleService('basic');
                        }}
                        className="flex-1 border border-white/15 bg-white/5 text-white/50 rounded-full py-1.5 md:py-2 px-3 text-[10px] md:text-xs font-medium tracking-wide uppercase flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap select-none"
                      >
                        <i className="ri-add-line" />
                        añadir extra
                      </div>
                    </div>
                  )}
                </div>
              </button>

              {/* Desplegable descripción lavado básico */}
              <div
                className="overflow-hidden transition-all duration-500 ease-in-out"
                style={{ maxHeight: isBasicOpen ? '1000px' : '0px', opacity: isBasicOpen ? 1 : 0 }}
              >
                <div className="px-5 pb-5 md:px-6 md:pb-6 border-t border-[#FFB800]/10">
                  <ul className="space-y-2 md:space-y-2.5 mt-4 md:mt-5">
                    {[
                      'Lavado y pre lavado básico',
                      'Limpieza de llantas y ruedas',
                      'Limpieza de cristales',
                      'Aspirado básico interior',
                      'Limpieza básica interior',
                    ].map((item, i) => (
                      <li
                        key={i}
                        className="flex items-start gap-2.5 md:gap-3 transition-all duration-300 ease-out"
                        style={{
                          transitionDelay: isBasicOpen ? `${i * 50}ms` : '0ms',
                          opacity: isBasicOpen ? 1 : 0,
                          transform: isBasicOpen ? 'translateY(0)' : 'translateY(-6px)',
                        }}
                      >
                        <span className="flex-shrink-0 w-4 h-4 md:w-5 md:h-5 flex items-center justify-center mt-0.5">
                          <i className="ri-check-line text-[#FFB800] text-xs md:text-sm" />
                        </span>
                        <span className="text-xs md:text-sm leading-relaxed text-white/70">
                          {item}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* === EXTRAS MÓVIL (entre las dos viñetas) === */}
          {isBasicOpen && (
            <div className="order-2 md:hidden">
              {extrasPanel}
            </div>
          )}

          {/* === ABSOLUTE DETAILING === */}
          <div className="order-3">
            <div
              className={`rounded-2xl overflow-hidden border bg-[#111] transition-all duration-300 relative animate-breathe ${
                isAbsoluteOpen ? 'border-[#FFB800] ring-1 ring-[#FFB800]/30' : 'border-[#FFB800]/40'
              }`}
            >
              {/* Circuito indicador esquina superior izquierda */}
              <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5">
                <span
                  className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                    isAbsoluteOpen
                      ? 'bg-[#FFB800] shadow-[0_0_10px_rgba(255,184,0,0.7)]'
                      : 'bg-white/15'
                  }`}
                />
                <span className={`text-[9px] md:text-[10px] tracking-wider uppercase font-light transition-colors duration-300 ${isAbsoluteOpen ? 'text-[#FFB800]' : 'text-white/20'}`}>
                  {isAbsoluteOpen ? 'Seleccionado' : ''}
                </span>
              </div>

              {/* Botón más info esquina superior derecha */}
              <div className="absolute top-3 right-3 z-10">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleService('absolute');
                  }}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-full border text-[9px] md:text-[10px] font-medium tracking-wider uppercase transition-all duration-300 cursor-pointer ${
                    isAbsoluteOpen
                      ? 'border-[#FFB800] bg-[#FFB800]/20 text-[#FFB800]'
                      : 'border-white/30 bg-black/40 text-white/70 backdrop-blur-sm'
                  }`}
                >
                  <i className={`ri-${isAbsoluteOpen ? 'arrow-up-s' : 'cursor'}-line text-xs`} />
                  {isAbsoluteOpen ? 'cerrar' : 'más info'}
                </button>
              </div>

              <button
                onClick={() => toggleService('absolute')}
                className="group relative w-full text-left cursor-pointer select-none touch-manipulation"
              >
                <div className="relative h-[200px] md:h-[260px] overflow-hidden">
                  <img
                    src={absoluteImage}
                    alt={absoluteService.name}
                    className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/50 pointer-events-none" />
                </div>
                <div className="px-5 py-4 md:px-6 md:py-5">
                  {absoluteService.slogan && (
                    <p className="text-[#FFB800] text-[10px] md:text-xs font-light tracking-[0.2em] uppercase mb-1">
                      {absoluteService.slogan}
                    </p>
                  )}
                  <h3 className="text-white text-base md:text-xl font-light tracking-[0.12em] uppercase mb-2 leading-tight">
                    {absoluteService.name}
                  </h3>
                  <p className="text-[#FFB800] text-2xl md:text-4xl font-bold leading-none mb-1">
                    {absolutePrice}€
                  </p>
                  {absoluteDuration && (
                    <p className="text-white/40 text-[10px] md:text-xs font-light">{absoluteDuration}</p>
                  )}
                  {!isAbsoluteOpen && (
                    <div className="flex items-center gap-2 mt-3 md:mt-4">
                      <a
                        href={absoluteWhatsappUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="flex-1 bg-[#FFB800] text-black rounded-full py-1.5 md:py-2 px-3 text-[10px] md:text-xs font-semibold tracking-wide uppercase hover:bg-[#FFA500] transition-colors duration-200 flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-whatsapp-line" />
                        Reservar
                      </a>

                      <div
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleService('absolute');
                        }}
                        className="flex-1 border border-white/15 bg-white/5 text-white/50 rounded-full py-1.5 md:py-2 px-3 text-[10px] md:text-xs font-medium tracking-wide uppercase flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap select-none"
                      >
                        <i className="ri-add-line" />
                        más info
                      </div>
                    </div>
                  )}
                </div>
              </button>

              {/* Desplegable unido a la viñeta */}
              <div
                className="overflow-hidden transition-all duration-500 ease-in-out"
                style={{ maxHeight: isAbsoluteOpen ? '1000px' : '0px', opacity: isAbsoluteOpen ? 1 : 0 }}
              >
                <div className="px-5 pb-5 md:px-6 md:pb-6 border-t border-[#FFB800]/10">
                  {/* Lista directa sobre negro */}
                  <ul className="space-y-2 md:space-y-2.5 mt-4 md:mt-5">
                    {absoluteService.included.map((item, i) => {
                      return (
                        <li
                          key={i}
                          className="flex items-start gap-2.5 md:gap-3 transition-all duration-300 ease-out"
                          style={{
                            transitionDelay: isAbsoluteOpen ? `${i * 50}ms` : '0ms',
                            opacity: isAbsoluteOpen ? 1 : 0,
                            transform: isAbsoluteOpen ? 'translateY(0)' : 'translateY(-6px)',
                          }}
                        >
                          <span className="flex-shrink-0 w-4 h-4 md:w-5 md:h-5 flex items-center justify-center mt-0.5">
                            <i className="ri-check-line text-[#FFB800] text-xs md:text-sm" />
                          </span>
                          <span className="text-xs md:text-sm leading-relaxed text-white/70">
                            {item}
                          </span>
                        </li>
                      );
                    })}
                  </ul>

                  <p className="text-white/30 text-[10px] md:text-xs italic text-center mb-4 md:mb-5 px-2 mt-4 md:mt-5 leading-relaxed">
                    Precio orientativo. El coste definitivo se confirma tras valoración presencial en función del estado del vehículo.
                  </p>

                  <a
                    href={absoluteWhatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-[#FFB800] text-black py-3 md:py-4 rounded-full font-semibold text-xs md:text-sm tracking-[0.15em] uppercase active:bg-[#FF9500] transition-colors duration-150 text-center flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-whatsapp-line text-sm md:text-lg" />
                    RESERVAR ABSOLUTE DETAILING
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* === EXTRAS DESKTOP (debajo de ambas viñetas) === */}
          {isBasicOpen && (
            <div className="order-4 hidden md:block col-span-2">
              {extrasPanel}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}